//Guia de telas:
// 0 = tela principal, 1 = instruções, 2 = créditos
// 3 = dificuldades, 4 = fácil, 5 = médio, 6 = dificil
// 7 = perdeu e 8 = ganhou

{
  var principal = 0; // Estado inicial
  var erro = 7; // Estado para tela de erro
  var sucesso = 8; // Novo estado para tela de sucesso
  var finalfacil = 0;
  var finalmedio = 0;
  var finaldificil = 0;
  
  var xback = 40;
  var yback = 345;
  var larguraback = 320; //voltar
  var alturaback = 50;

  // Definições dos botões (menu, instruções, créditos, voltar, dificuldade, alternativas)
  var botoesMenu = [
    { x: 40, y: 150, largura: 320, altura: 50 }, // começar o jogo
    { x: 40, y: 225, largura: 320, altura: 50 }, // instruções
    { x: 40, y: 300, largura: 320, altura: 50 }, // créditos
  ];

  var botaoVoltar = { x: 40, y: 345, largura: 320, altura: 50 }; // voltar

  var botoesDificuldade = [
    { x: 75, y: 120, largura: 250, altura: 50 }, // fácil
    { x: 75, y: 180, largura: 250, altura: 50 }, // médio
    { x: 75, y: 240, largura: 250, altura: 50 }, // difícil
  ];

  var botoesAlternativas = [
    { x: 90, y: 255, largura: 230, altura: 40 }, // alternativa A
    { x: 90, y: 305, largura: 230, altura: 40 }, // alternativa B
    { x: 90, y: 355, largura: 230, altura: 40 }, // alternativa C
  ];

  var questao;
  
   
  var intervalosQuestao = [
  { min: 6, max: 10, novoPrincipal: 5, novoQuestao: 6 },
  { min: 1, max: 5, novoPrincipal: 4, novoQuestao: 1 },
  { min: 11, max: 15, novoPrincipal: 6, novoQuestao: 11 }
];
var coordsBack = { x: xback, y: yback, largura: larguraback, altura: alturaback };
} // vars
function preload() {
  img = loadImage("imagem.jpg");
  brasil = loadImage("brasil.jpg");
  eua = loadImage("eua.jpg");
  mex = loadImage("mexx.jpeg");
  fra = loadImage("fra.jpeg");
  chi = loadImage("chi.jpeg");
  arg = loadImage("arg.jpeg");
  can = loadImage("can.jpg");
  ale = loadImage("ale.jpg");
  tur = loadImage("tur.jpeg");
  nor = loadImage("nor.jpeg");
  pol = loadImage("pol.png");
  kuw = loadImage("kuw.jpeg");
  ira = loadImage("ira.jpeg");
  col = loadImage("col.jpeg");
  esl = loadImage("esl.jpeg");
}
function setup() {
  createCanvas(400, 400);
}
function draw() {
  background(img);
  if (principal == 0) {
    Menu(); // ir para o menu
  } else if (principal == 1) {
    Instrucoes(); // ir para instruções
  } else if (principal == 2) {
    Creditos(); // ir para créditos
  } else if (principal == 3) {
    Opcoes(); // ir para opções
  } else if (principal == 4) {
    facil(); // fase fácil
  } else if (principal == 5) {
    medio(); // fase médio
  } else if (principal == 6) {
    dificil(); // fase difícil
  } else if (principal == erro) {
    Erro(); // perdeu
  } else if (principal == sucesso) {
    Sucesso(); // ganhou
   }else if (principal == 9) {
    Vencedor(); //ganhou
  }
}


function mouseClicked() {
  if (principal == 0) {
    MenuClique();
  } else if (principal == 1) {
    InstrucoesClique();
  } else if (principal == 2) {
    CreditosClique();
  } else if (principal == 3) {
    DificuldadeClique();
  } else if (principal == 4) {
    FacilClique();
  } else if (principal == 5) {
    MedioClique();
  } else if (principal == 6) {
    DificilClique();
  } else if (principal == erro) {
    ErroClique();
  } else if (principal == sucesso) {
    SucessoClique();
  } else if (principal == 9) {
    VencedorClique(); //ganhou
  }
}
function MenuClique() {
  if (
    mouseX > botoesMenu[0].x &&
    mouseX < botoesMenu[0].x + botoesMenu[0].largura &&
    mouseY > botoesMenu[0].y &&
    mouseY < botoesMenu[0].y + botoesMenu[0].altura
  ) {
    principal = 3;
  }
  if (
    mouseX > botoesMenu[1].x &&
    mouseX < botoesMenu[1].x + botoesMenu[1].largura &&
    mouseY > botoesMenu[1].y &&
    mouseY < botoesMenu[1].y + botoesMenu[1].altura
  ) {
    principal = 1;
  }
  if (
    mouseX > botoesMenu[2].x &&
    mouseX < botoesMenu[2].x + botoesMenu[2].largura &&
    mouseY > botoesMenu[2].y &&
    mouseY < botoesMenu[2].y + botoesMenu[2].altura
  ) {
    principal = 2;
  }
}
function InstrucoesClique() {
  if (
    mouseX > botaoVoltar.x &&
    mouseX < botaoVoltar.x + botaoVoltar.largura &&
    mouseY > botaoVoltar.y &&
    mouseY < botaoVoltar.y + botaoVoltar.altura
  ) {
    principal = 0;
  }
}
function CreditosClique() {
  if (
    mouseX > botaoVoltar.x &&
    mouseX < botaoVoltar.x + botaoVoltar.largura &&
    mouseY > botaoVoltar.y &&
    mouseY < botaoVoltar.y + botaoVoltar.altura
  ) {
    principal = 0;
  }
}
function DificuldadeClique() {
  if (finalfacil == 0) {
    if (
      mouseX > botoesDificuldade[0].x &&
      mouseX < botoesDificuldade[0].x + botoesDificuldade[0].largura &&
      mouseY > botoesDificuldade[0].y &&
      mouseY < botoesDificuldade[0].y + botoesDificuldade[0].altura
    ) {
      principal = 4;
      questao = 1;
    }
  } else if (finalfacil == 1) {
    if (
      mouseX > botoesDificuldade[0].x &&
      mouseX < botoesDificuldade[0].x + botoesDificuldade[0].largura &&
      mouseY > botoesDificuldade[0].y &&
      mouseY < botoesDificuldade[0].y + botoesDificuldade[0].altura
    ) {
      alert("Você já concluiu essa fase, passe para a próxima");
    }
  } // modo fácil
  if (finalmedio == 0) {
    if (
      mouseX > botoesDificuldade[1].x &&
      mouseX < botoesDificuldade[1].x + botoesDificuldade[1].largura &&
      mouseY > botoesDificuldade[1].y &&
      mouseY < botoesDificuldade[1].y + botoesDificuldade[1].altura
    ) {
      principal = 5;
      questao = 6;
    }
  } else if (finalmedio == 1) {
    if (
      mouseX > botoesDificuldade[1].x &&
      mouseX < botoesDificuldade[1].x + botoesDificuldade[1].largura &&
      mouseY > botoesDificuldade[1].y &&
      mouseY < botoesDificuldade[1].y + botoesDificuldade[1].altura
    ) {
      alert("Você já concluiu essa fase, passe para a próxima");
    }
  } // modo médio
  if (finaldificil == 0) {
    if (
      mouseX > botoesDificuldade[2].x &&
      mouseX < botoesDificuldade[2].x + botoesDificuldade[2].largura &&
      mouseY > botoesDificuldade[2].y &&
      mouseY < botoesDificuldade[2].y + botoesDificuldade[2].altura
    ) {
      principal = 6;
      questao = 11;
    }
  } else if (finaldificil == 1) {
    if (
      mouseX > botoesDificuldade[2].x &&
      mouseX < botoesDificuldade[2].x + botoesDificuldade[2].largura &&
      mouseY > botoesDificuldade[2].y &&
      mouseY < botoesDificuldade[2].y + botoesDificuldade[2].altura
    ) {
      alert("Você já concluiu essa fase");
    }
  } // modo difícil
  if (
    mouseX > botaoVoltar.x &&
    mouseX < botaoVoltar.x + botaoVoltar.largura &&
    mouseY > botaoVoltar.y &&
    mouseY < botaoVoltar.y + botaoVoltar.altura
  ) {
    principal = 0;
  } // botão voltar
}
function FacilClique() {
  if (questao === 1) {
    if (
      mouseX > ax &&
      mouseX < ax + larguraa &&
      mouseY > ay &&
      mouseY < ay + alturaa
    ) {
      console.log("Certo!");
      questao = 2;
    } else if (
      (mouseX > bx &&
        mouseX < bx + largurab &&
        mouseY > by &&
        mouseY < by + alturab) ||
      (mouseX > cx &&
        mouseX < cx + largurac &&
        mouseY > cy &&
        mouseY < cy + alturac)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 2) {
    if (
      mouseX > Cx &&
      mouseX < Cx + larguraC &&
      mouseY > Cy &&
      mouseY < Cy + alturaC
    ) {
      console.log("Certo!");
      questao = 3;
    } else if (
      (mouseX > Bx &&
        mouseX < Bx + larguraB &&
        mouseY > By &&
        mouseY < By + alturaB) ||
      (mouseX > Ax &&
        mouseX < Ax + larguraA &&
        mouseY > Ay &&
        mouseY < Ay + alturaA)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 3) {
    if (
      mouseX > BX &&
      mouseX < BX + Largurab &&
      mouseY > BY &&
      mouseY < BY + Alturab
    ) {
      console.log("Certo!");
      questao = 4;
    } else if (
      (mouseX > AX &&
        mouseX < AX + Larguraa &&
        mouseY > AY &&
        mouseY < AY + Alturaa) ||
      (mouseX > CX &&
        mouseX < CX + Largurac &&
        mouseY > CY &&
        mouseY < CY + Alturac)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 4) {
    if (
      mouseX > B_X &&
      mouseX < B_X + B_W &&
      mouseY > B_Y &&
      mouseY < B_Y + B_H
    ) {
      console.log("Certo!");
      questao = 5;
    } else if (
      (mouseX > A_X &&
        mouseX < A_X + A_W &&
        mouseY > A_Y &&
        mouseY < A_Y + A_H) ||
      (mouseX > C_X && mouseX < C_X + C_W && mouseY > C_Y && mouseY < C_Y + C_H)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 5) {
    if (
      mouseX > a_X &&
      mouseX < a_X + a_W &&
      mouseY > a_Y &&
      mouseY < a_Y + a_H
    ) {
      console.log("Certo!");
      principal = sucesso;
    } else if (
      (mouseX > b_X &&
        mouseX < b_X + b_W &&
        mouseY > b_Y &&
        mouseY < b_Y + b_H) ||
      (mouseX > c_X && mouseX < c_X + c_W && mouseY > c_Y && mouseY < c_Y + c_H)
    ) {
      console.log("Errado");
      principal = erro;
    }
  }
}
function MedioClique() {
  if (questao === 6) {
    if (
      mouseX > cxx &&
      mouseX < cxx + larguracc &&
      mouseY > cyy &&
      mouseY < cyy + alturacc
    ) {
      console.log("Certo!");
      questao = 7;
    } else if (
      (mouseX > bxx &&
        mouseX < bxx + largurabb &&
        mouseY > byy &&
        mouseY < byy + alturabb) ||
      (mouseX > axx &&
        mouseX < axx + larguraaa &&
        mouseY > ayy &&
        mouseY < ayy + alturaaa)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao == 7) {
    if (mouseX > xB && mouseX < xB + wB && mouseY > yB && mouseY < yB + hB) {
      console.log("Certo!");
      questao = 8;
    } else if (
      (mouseX > xC && mouseX < xC + wC && mouseY > yC && mouseY < yC + hC) ||
      (mouseX > xA && mouseX < xA + wA && mouseY > yA && mouseY < yA + hA)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao == 8) {
    if (
      mouseX > posXA &&
      mouseX < posXA + larguraaA &&
      mouseY > posYA &&
      mouseY < posYA + alturraaA
    ) {
      console.log("Certo!");
      questao = 9;
    } else if (
      (mouseX > posXB &&
        mouseX < posXB + larguraaB &&
        mouseY > posYB &&
        mouseY < posYB + alturraaB) ||
      (mouseX > posXC &&
        mouseX < posXC + larguraaC &&
        mouseY > posYC &&
        mouseY < posYC + alturraaC)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao == 9) {
    if (
      mouseX > posxb &&
      mouseX < posxb + largurallab &&
      mouseY > posyb &&
      mouseY < posyb + alturallab
    ) {
      console.log("Certo!");
      questao = 10; // Próxima questão
    } else if (
      (mouseX > posxa &&
        mouseX < posxa + largurallaa &&
        mouseY > posya &&
        mouseY < posya + alturallaa) ||
      (mouseX > posxc &&
        mouseX < posxc + largurallac &&
        mouseY > posyc &&
        mouseY < posyc + alturallac)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao == 10) {
    if (
      mouseX > posicaoXC &&
      mouseX < posicaoXC + larguraAltC &&
      mouseY > posicaoYC &&
      mouseY < posicaoYC + alturaAltC
    ) {
      console.log("Certo!");
      principal = sucesso;
    } else if (
      (mouseX > posicaoXA &&
        mouseX < posicaoXA + larguraAltA &&
        mouseY > posicaoYA &&
        mouseY < posicaoYA + alturaAltA) ||
      (mouseX > posicaoXB &&
        mouseX < posicaoXB + larguraAltB &&
        mouseY > posicaoYB &&
        mouseY < posicaoYB + alturaAltB)
    ) {
      console.log("Errado");
      principal = erro;
    }
  }
}
function DificilClique() {
  if (questao === 11) {
    if (
      mouseX > poloniaX &&
      mouseX < poloniaX + poloniaLargura &&
      mouseY > poloniaY &&
      mouseY < poloniaY + poloniaAltura
    ) {
      console.log("Certo!");
      questao = 12;
    } else if (
      (mouseX > monacoX &&
        mouseX < monacoX + monacoLargura &&
        mouseY > monacoY &&
        mouseY < monacoY + monacoAltura) ||
      (mouseX > indonesiaX &&
        mouseX < indonesiaX + indonesiaLargura &&
        mouseY > indonesiaY &&
        mouseY < indonesiaY + indonesiaAltura)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 12) {
    if (
      mouseX > kuwaitX &&
      mouseX < kuwaitX + kuwaitLargura &&
      mouseY > kuwaitY &&
      mouseY < kuwaitY + kuwaitAltura
    ) {
      console.log("Certo!");
      questao = 13;
    } else if (
      (mouseX > jordaniaX &&
        mouseX < jordaniaX + jordaniaLargura &&
        mouseY > jordaniaY &&
        mouseY < jordaniaY + jordaniaAltura) ||
      (mouseX > sudaoX &&
        mouseX < sudaoX + sudaoLargura &&
        mouseY > sudaoY &&
        mouseY < sudaoY + sudaoAltura)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 13) {
    if (
      mouseX > iraqueX &&
      mouseX < iraqueX + iraqueLargura &&
      mouseY > iraqueY &&
      mouseY < iraqueY + iraqueAltura
    ) {
      console.log("Certo!");
      questao = 14;
    } else if (
      (mouseX > egitoX &&
        mouseX < egitoX + egitoLargura &&
        mouseY > egitoY &&
        mouseY < egitoY + egitoAltura) ||
      (mouseX > siriaX &&
        mouseX < siriaX + siriaLargura &&
        mouseY > siriaY &&
        mouseY < siriaY + siriaAltura)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 14) {
    if (
      mouseX > colombiaX &&
      mouseX < colombiaX + colombiaLargura &&
      mouseY > colombiaY &&
      mouseY < colombiaY + colombiaAltura
    ) {
      console.log("Certo!");
      questao = 15;
    } else if (
      (mouseX > ecuadorX &&
        mouseX < ecuadorX + ecuadorLargura &&
        mouseY > ecuadorY &&
        mouseY < ecuadorY + ecuadorAltura) ||
      (mouseX > romeniaX &&
        mouseX < romeniaX + romeniaLargura &&
        mouseY > romeniaY &&
        mouseY < romeniaY + romeniaAltura)
    ) {
      console.log("Errado");
      principal = erro;
    }
  } else if (questao === 15) {
    if (
      mouseX > croaciaX &&
      mouseX < croaciaX + croaciaLargura &&
      mouseY > croaciaY &&
      mouseY < croaciaY + croaciaAltura
    ) {
      console.log("Certo!");
      principal = sucesso;
    } else if (
      (mouseX > serviaX &&
        mouseX < serviaX + serviaLargura &&
        mouseY > serviaY &&
        mouseY < serviaY + serviaAltura) ||
      (mouseX > eslovaquiaX &&
        mouseX < eslovaquiaX + eslovaquiaLargura &&
        mouseY > eslovaquiaY &&
        mouseY < eslovaquiaY + eslovaquiaAltura)
    ) {
      console.log("Errado");
      principal = erro;
    }
  }
}
function ErroClique() {
  for (var i = 0; i < intervalosQuestao.length; i++) {
    var intervalo = intervalosQuestao[i];
    if (principal == 7 && questao >= intervalo.min && questao <= intervalo.max) {
      if (
        mouseX > coordsBack.x &&
        mouseX < coordsBack.x + coordsBack.largura &&
        mouseY > coordsBack.y &&
        mouseY < coordsBack.y + coordsBack.altura
      ) {
        console.log("perdeu");
        questao = intervalo.novoQuestao;
        principal = intervalo.novoPrincipal;
      }
    }
  }
}
function SucessoClique() {
  if (principal == 8 && questao == 5) {
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      principal = 3; // Volta para a tela de facil;
      questao = 0;
      finalfacil = 1;
    }
  }
  if (principal == 8 && questao == 10) {
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      principal = 3; // Volta para a tela de facil;
      questao = 0;
      finalmedio = 1;
    }
  }
  if (principal == 8 && questao == 15) {
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      principal = 3; // Volta para a tela de fácil;
      questao = 0;
      finaldificil = 1;
    }
  }
  // Verifica se todas as fases foram completadas
  if (finaldificil == 1 && finalmedio == 1 && finalfacil == 1) {
    principal = 9; // Volta para a tela de fácil;
      questao = 0;
      finaldificil = 1;
    console.log("yassss")
  }
}
function VencedorClique() {
if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      principal = 0; // Volta para a tela de fácil;
      questao = 0;
      finaldificil = 0;
  finalmedio = 0
  finalfacil = 0
    }
  }
