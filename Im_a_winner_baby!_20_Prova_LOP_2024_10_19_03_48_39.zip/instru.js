function Instrucoes() {
  fill(275, 198, 228);
  rect(50, 25, 300, 50, 30);
  rect(30, 135, 350, 150, 30);

  fill(0);
  textSize(30);
  textAlign(CENTER);
  text("Instruções", 200, 60);
  textSize(20);
  fill(0);
  text(
    "O Jogo das Bandeiras testa seu" +
    "\n" +
    "conhecimento sobre as bandeiras" +
    "\n" +
    "de países. Escolha a dificuldade e " +
    "\n" +
    "identifique nas bandeiras exibidas" +
    "\n" +
    "para ganhar!",
    205, 165
  );

  var botoes = [
    { x: 40, y: 345, largura: 320, altura: 50, texto: "Clique para voltar" }
  ];

  for (var i = 0; i < botoes.length; i++) {
    var botao = botoes[i];
    
    // Verificar e desenhar o botão
    fill(247, 198, 228);
    if (
      mouseX > botao.x &&
      mouseX < botao.x + botao.largura &&
      mouseY > botao.y &&
      mouseY < botao.y + botao.altura
    ) {
      fill(235, 162, 219);
    }
    rect(botao.x, botao.y, botao.largura, botao.altura, 10);
    
    // Adicionar o texto do botão
    fill(0);
    textSize(30);
    text(botao.texto, botao.x + botao.largura / 2, botao.y + botao.altura / 2 + 10);
  }
}