function Erro() {
  fill(275, 198, 228);
  rect(50, 25, 300, 50, 30);
  fill(0);
  textSize(30);
  textAlign(CENTER)
  text("Resposta Errada", 200, 60);
  textSize(20);
  text("Você clicou na opção errada." + "\n" +"Tente novamente!", 200, 100);

  fill(247, 198, 228);
  if (
    mouseX > xback &&
    mouseX < xback + larguraback &&
    mouseY > yback &&
    mouseY < yback + alturaback
  ) {
    fill(235, 162, 219);
  }
  rect(xback, yback, larguraback, alturaback, 30);
  fill(0);
  textSize(30);
  text("Clique para voltar", 200,380);
}