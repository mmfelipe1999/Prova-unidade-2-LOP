var botoes = [
  { x: 75, y: 120, largura: 250, altura: 50, texto: "Fácil" },
  { x: 75, y: 180, largura: 250, altura: 50, texto: "Médio" },
  { x: 75, y: 240, largura: 250, altura: 50, texto: "Difícil" },
  { x: 40, y: 345, largura: 320, altura: 50, texto: "Clique para voltar" }
];

function Opcoes() {
  fill(275, 198, 228);
  rect(20, 25, 365, 50, 30);
  fill(0);
  textSize(30);
  textAlign(CENTER);
  text("Selecione a Dificuldade", 200, 60);

  for (var i = 0; i < botoes.length; i++) {
    var botao = botoes[i];
    
    // Verificar e desenhar o botão
    fill(247, 198, 228);
    if (
      mouseX > botao.x &&
      mouseX < botao.x + botao.largura &&
      mouseY > botao.y &&
      mouseY < botao.y + botao.altura
    ) {
      fill(235, 162, 219);
    }
    rect(botao.x, botao.y, botao.largura, botao.altura, 15);
    
    // Adicionar o texto do botão
    fill(0);
    textSize(30);
    text(botao.texto, botao.x + botao.largura / 2, botao.y + botao.altura / 2 + 10);
  }
}
