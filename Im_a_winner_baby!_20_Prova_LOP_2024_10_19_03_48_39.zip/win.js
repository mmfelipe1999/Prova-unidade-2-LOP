function Vencedor() {
  textAlign(CENTER)
  fill(275, 198, 228);
  rect(50, 25, 300, 50, 30);
  fill(0);
  textSize(40);
  textFont("Century Gothic");
  text("PARABÉNS", 200, 65)
  textSize(20)
    text("Você concluiu o quiz das bandeiras" + "\n" + "e tem muito conhecimento delas"+"\n"+ "você arrasou demais!", 200, 120)
  
  fill(247, 198, 228);
  if (
    mouseX > xback &&
    mouseX < xback + larguraback &&
    mouseY > yback &&
    mouseY < yback + alturaback
  ) {
    fill(235, 162, 219);
  }
  rect(xback, yback, larguraback, alturaback, 10);
  fill(0);
  textSize(21);
  text("Clique para começar denovo!", 200, 378);
}