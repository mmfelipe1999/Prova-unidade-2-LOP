{var ax = 90;
var ay = 255;
var larguraa = 230;
var alturaa = 40; 

var bx = 90;
var by = 305;
var largurab = 230;
var alturab = 40;

var cx = 90;
var cy = 355;
var largurac = 230;
var alturac = 40;} //alternativas primeira questão
{var Ax = 90;
var Ay = 255;
var larguraA = 230;
var alturaA = 40;

var Bx = 90;
var By = 305;
var larguraB = 230;
var alturaB = 40;

var Cx = 90;
var Cy = 355;
var larguraC = 230;
var alturaC = 40;
}//alternativas segunda questão
{var AX = 90;
var AY = 255;
var Larguraa = 230;
var Alturaa = 40;

var BX = 90;
var BY = 305;
var Largurab = 230;
var Alturab = 40;

var CX = 90;
var CY = 355;
var Largurac = 230;
var Alturac = 40;
}//alternativas terceira questão
{var A_X = 90;
var A_Y = 255;
var A_W = 230;  // Largura
var A_H = 40;   // Altura

var B_X = 90;
var B_Y = 305;
var B_W = 230;  // Largura
var B_H = 40;   // Altura

var C_X = 90;
var C_Y = 355;
var C_W = 230;  // Largura
var C_H = 40;   // Altura
}//alternativas quarta questão
{var a_X = 90;
var a_Y = 255;
var a_W = 230;  // Largura
var a_H = 40;   // Altura

var b_X = 90;
var b_Y = 305;
var b_W = 230;  // Largura
var b_H = 40;   // Altura

var c_X = 90;
var c_Y = 355;
var c_W = 230;  // Largura
var c_H = 40;   // Altura
}//alternativas quinta questão

// Definindo variáveis para alternativas de cada questão
var questoes = [
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 1
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 2
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 3
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 4
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }  // Questão 5
];

; // Vetor com as imagens das bandeiras
var textoss = [
  ["Brasil", "Honduras", "Espanha"],         // Questão 1
  ["Espanha", "República Tcheca", "Estados Unidos"], // Questão 2
  ["Grécia", "México", "Canadá"],             // Questão 3
  ["Índia", "França", "Inglaterra"],          // Questão 4
  ["China", "Alemanha", "Turquia"]            // Questão 5
];

function facil() {
  var imagens = [brasil, eua, mex, fra, chi]
  var questaoAtual = questao - 1; // Ajusta a questão atual para o índice do array
  
  fill(275, 198, 228);
  circle(45, 45, 30);
  fill(0);
  textSize(20);
  text(questao, 45, 52);

  fill(275, 198, 228);
  rect(70, 25, 300, 40, 30);
  fill(0);
  textSize(20);
  textFont("Century Gothic");
  text("De que país é essa bandeira?", 220, 52);

  // Imagem da bandeira
  image(imagens[questaoAtual], 80, 95, 250, 150);

  // Desenhar alternativas
  for (var i = 0; i < 3; i++) {
    var x = questoes[questaoAtual].x[i];
    var y = questoes[questaoAtual].y[i];
    var w = questoes[questaoAtual].w[i];
    var h = questoes[questaoAtual].h[i];
    
    fill(247, 198, 228);
    if (mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
      fill(235, 162, 219);
    }
    rect(x, y, w, h, 30);
  }

  // Texto das alternativas
  fill(0);
  textAlign(CENTER);
  for (var i = 0; i < 3; i++) {
    text(textoss[questaoAtual][i], 200, 280 + i * 50);
  }
}