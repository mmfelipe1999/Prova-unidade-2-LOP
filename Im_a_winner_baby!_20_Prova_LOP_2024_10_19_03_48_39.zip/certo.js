function Sucesso() { 
  if (principal == 8 && questao == 5) {
    fill(275, 198, 228);
    rect(50, 25, 300, 50, 30);
    fill(0);
    textSize(30);
    textAlign(CENTER);
    text("Arrasou muito!", 200, 60);
    textSize(20);
    text("Você completou a fase fácil." + "\n" + "Parabéns!", 200, 100);
 
    fill(247, 198, 228);
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      fill(235, 162, 219);
    }
    rect(xback, yback, larguraback, alturaback, 30);
    fill(0);
    textSize(30);
    text("Clique para voltar", 200, 380);
  } 
  else if (principal == 8 && questao == 10) {
    fill(275, 198, 228);
    rect(50, 25, 300, 50, 30);
    fill(0);
    textSize(30);
    textAlign(CENTER);
    text("Você conseguiu!!!", 200, 60);
    textSize(20);
    text("Você completou a fase média." + "\n" + "Que orgulho!", 200, 100);

    fill(247, 198, 228);
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      fill(235, 162, 219);
    }
    rect(xback, yback, larguraback, alturaback, 30);
    fill(0);
    textSize(30);
    text("Clique para voltar", 200, 380);
  }
   else if (principal == 8 && questao == 15) {
    fill(275, 198, 228);
    rect(50, 25, 300, 50, 30);
    fill(0);
    textSize(30);
    textAlign(CENTER);
    text("Mais uma vez!!!!", 200, 60);
    textSize(20);
    text("Você completou a fase difícil." + "\n" + "Você é muito inteligente!", 200, 100);

    fill(247, 198, 228);
    if (
      mouseX > xback &&
      mouseX < xback + larguraback &&
      mouseY > yback &&
      mouseY < yback + alturaback
    ) {
      fill(235, 162, 219);
    }
    rect(xback, yback, larguraback, alturaback, 30);
    fill(0);
    textSize(30);
    text("Clique para voltar", 200, 380);
  }
  
  
  
  
}
