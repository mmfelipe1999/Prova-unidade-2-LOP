var posicoesBotoes = [
  { x: 40, y: 150, largura: 320, altura: 50 }, // Começar
  { x: 40, y: 225, largura: 320, altura: 50 }, // Instruções
  { x: 40, y: 300, largura: 320, altura: 50 }, // Créditos
];
function Menu() {
  fill(275, 198, 228);
  rect(50, 25, 300, 50, 30);
  fill(0);
  textFont("Century Gothic");
  textSize(30);
  textAlign(CENTER);
  text("Jogo das bandeiras", 200, 60);

  // Desenha os botões usando um loop for
  for (var i = 0; i < posicoesBotoes.length; i++) {
    var botao = posicoesBotoes[i];
    fill(247, 198, 228);

    if (
      mouseX > botao.x &&
      mouseX < botao.x + botao.largura &&
      mouseY > botao.y &&
      mouseY < botao.y + botao.altura
    ) {
      fill(235, 162, 219);
    }

    rect(botao.x, botao.y, botao.largura, botao.altura, 10);
    fill(0);

    // Define o texto de acordo com o índice do botão
    var textoBotao = "";
    if (i === 0) {
      textoBotao = "Começar jogo";
    } else if (i === 1) {
      textoBotao = "Instruções";
    } else if (i === 2) {
      textoBotao = "Créditos";
    }

    text(textoBotao, 200, botao.y + 35);
  }
}
