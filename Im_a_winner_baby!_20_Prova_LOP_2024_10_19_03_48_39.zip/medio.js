{var axx = 90;
var ayy = 255;
var larguraaa = 230;
var alturaaa = 40; 

var bxx = 90;
var byy = 305;
var largurabb = 230;
var alturabb = 40;

var cxx = 90;
var cyy = 355;
var larguracc = 230;
var alturacc = 40;} // altenativas sexta questao médio
{var xA = 90;
var yA = 255;
var wA = 230;
var hA = 40;

var xB = 90;
var yB = 305;
var wB = 230;
var hB = 40;

var xC = 90;
var yC = 355;
var wC = 230;
var hC = 40;
} //alternativas sétima questao
{var posXA = 90;
var posYA = 255;
var larguraaA = 230;
var alturraaA = 40;

var posXB = 90;
var posYB = 305;
var larguraaB = 230;
var alturraaB = 40;

var posXC = 90;
var posYC = 355;
var larguraaC = 230;
var alturraaC = 40;
} // alternativa oitava questao
{var posxa = 90;
var posya = 255;
var largurallaa = 230;
var alturallaa = 40;

var posxb = 90;
var posyb = 305;
var largurallab = 230;
var alturallab = 40;

var posxc = 90;
var posyc = 355;
var largurallac = 230;
var alturallac = 40;
} // alternativas nona questao
{var posicaoXA = 90;
var posicaoYA = 255;
var larguraAltA = 230;
var alturaAltA = 40;

var posicaoXB = 90;
var posicaoYB = 305;
var larguraAltB = 230;
var alturaAltB = 40;

var posicaoXC = 90;
var posicaoYC = 355;
var larguraAltC = 230;
var alturaAltC = 40;
} // alternativas décima questao
function medio() {
  var questoes = [
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 6
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 7
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 8
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Questão 9
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }  // Questão 10
];

var imagens = [arg, can, ale, tur, nor] // Vetor com as imagens das bandeiras
var textos = [
  ["Guatemala", "Uruguai", "Argentina"], // Questão 6
  ["Japão", "Canadá", "Suiça"],         // Questão 7
  ["Alemanha", "Bélgica", "Espanha"],    // Questão 8
  ["Tunísia", "Turquia", "Paquistão"],   // Questão 9
  ["Suíça", "Dinamarca", "Noruega"]      // Questão 10
];
  var questaoAtual = questao - 6; // Determina a questão atual com base em 'questao'
  fill(275, 198, 228);
  circle(45, 45, 30);
  fill(0);
  textSize(20);
  text(questao, 45, 52);
  fill(275, 198, 228);
  rect(70, 25, 300, 40, 30);
  fill(0);
  textSize(20);
  textFont("Century Gothic");
  text("De que país é essa bandeira?", 220, 52);



  // Imagem da bandeira
  image(imagens[questaoAtual], 80, 95, 250, 150);

  // Desenhar alternativas
  for (var i = 0; i < 3; i++) {
    var x = questoes[questaoAtual].x[i];
    var y = questoes[questaoAtual].y[i];
    var w = questoes[questaoAtual].w[i];
    var h = questoes[questaoAtual].h[i];
    fill(247, 198, 228);
    if (mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
      fill(235, 162, 219);
    }
    rect(x, y, w, h, 30);
  }

  // Texto das alternativas
  fill(0);
  textAlign(CENTER);
  for (var i = 0; i < 3; i++) {
    text(textos[questaoAtual][i], 200, 280 + i * 50);
  }
}
