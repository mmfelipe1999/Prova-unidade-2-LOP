function Creditos() {
  fill(275, 198, 228);
  rect(50, 25, 300, 50, 30);
  fill(0);
  textSize(30);
  textAlign(CENTER);
  text("Créditos", 200, 60);

  fill(275, 198, 228);
  rect(8, 135, 385, 55, 30);
  fill(0);
  textSize(18);
  text("Este jogo foi construído e programado por:", 200, 160);
  text("Matheus Felipe de Oliveira", 200, 180);

  var botoes = [
    { x: 40, y: 345, largura: 320, altura: 50, texto: "Clique para voltar" }
  ];

  for (var i = 0; i < botoes.length; i++) {
    var botao = botoes[i];
    
    // Verificar e desenhar o botão
    fill(247, 198, 228);
    if (
      mouseX > botao.x &&
      mouseX < botao.x + botao.largura &&
      mouseY > botao.y &&
      mouseY < botao.y + botao.altura
    ) {
      fill(235, 162, 219);
    }
    rect(botao.x, botao.y, botao.largura, botao.altura, 10);
    
    // Adicionar o texto do botão
    fill(0);
    textSize(30);
    text(botao.texto, botao.x + botao.largura / 2, botao.y + botao.altura / 2 + 10);
  }
}