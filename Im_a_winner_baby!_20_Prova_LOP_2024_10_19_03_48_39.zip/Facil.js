function Facil() {
  fill(275, 198, 228);
  rect(70, 25, 300, 40, 30);
  fill(0);
  textSize(20);
  textFont("Century Gothic");
  text("De que país é essa bandeira?", 220, 52);
  image(brasil, 88, 95, 250, 150);

  fill(275, 198, 228);
  rect(ax, ay, larguraa, alturaa, 30);
  rect(bx, by, largurab, alturab, 30);
  rect(cx, cy, largurac, alturac, 30);
  fill(0);
  textAlign(CENTER);
  text("Brasil", 200, 280);
  text("Honduras", 200, 330);
  text("Espanha", 200, 380);
}