{
  {var poloniaX = 90;
var poloniaY = 255;
var poloniaLargura = 230;
var poloniaAltura = 40; 

var monacoX = 90;
var monacoY = 305;
var monacoLargura = 230;
var monacoAltura = 40;

var indonesiaX = 90;
var indonesiaY = 355;
var indonesiaLargura = 230;
var indonesiaAltura = 40;
} //alternativas 11 perguntas
{var jordaniaX = 90;
var jordaniaY = 255;
var jordaniaLargura = 230;
var jordaniaAltura = 40; 

var sudaoX = 90;
var sudaoY = 305;
var sudaoLargura = 230;
var sudaoAltura = 40;

var kuwaitX = 90;
var kuwaitY = 355;
var kuwaitLargura = 230;
var kuwaitAltura = 40;
}//alternativas 12 perguntas
{var iraqueX = 90;
var iraqueY = 255;
var iraqueLargura = 230;
var iraqueAltura = 40;

var egitoX = 90;
var egitoY = 305;
var egitoLargura = 230;
var egitoAltura = 40;

var siriaX = 90;
var siriaY = 355;
var siriaLargura = 230;
var siriaAltura = 40;
}//alternantivas 13 pergunta
{var colombiaX = 90;
var colombiaY = 255;
var colombiaLargura = 230;
var colombiaAltura = 40;

var ecuadorX = 90;
var ecuadorY = 305;
var ecuadorLargura = 230;
var ecuadorAltura = 40;

var romeniaX = 90;
var romeniaY = 355;
var romeniaLargura = 230;
var romeniaAltura = 40;
}//alternativas 14 perguntas
{var serviaX = 90;
var serviaY = 255;
var serviaLargura = 230;
var serviaAltura = 40;

var eslovaquiaX = 90;
var eslovaquiaY = 305;
var eslovaquiaLargura = 230;
var eslovaquiaAltura = 40;

var croaciaX = 90;
var croaciaY = 355;
var croaciaLargura = 230;
var croaciaAltura = 40;
}
}//vars
// Definindo textos para alternativas de cada questão
var textos = [
  ["Polônia", "Mônaco", "Indonésia"], // Alternativas 11
  ["Jordânia", "Sudão", "Kuwait"], // Alternativas 12
  ["Iraque", "Egito", "Síria"], // Alternativas 13
  ["Colômbia", "Equador", "Romênia"], // Alternativas 14
  ["Croácia", "Sérvia", "Eslováquia"] // Alternativas 15
];


// Definindo coordenadas e tamanhos das alternativas para cada questão
var questoes = [
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Alternativas 11
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Alternativas 12
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Alternativas 13
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }, // Alternativas 14
  { x: [90, 90, 90], y: [255, 305, 355], w: [230, 230, 230], h: [40, 40, 40] }  // Alternativas 15
];
function dificil() {
  var imagens = [pol, kuw, ira, col, esl];
  var questaoAtual = questao - 11; // Ajusta o índice da questão para acessar o vetor correto
  
  fill(275, 198, 228);
  circle(45, 45, 30);
  fill(0);
  textSize(20);
  text(questao, 45, 52);

  fill(275, 198, 228);
  rect(70, 25, 300, 40, 30);
  fill(0);
  textSize(20);
  textFont("Century Gothic");
  text("De que país é essa bandeira?", 220, 52);

  // Imagem da bandeira
  image(imagens[questaoAtual], 80, 95, 250, 150);

  // Desenhar alternativas
  for (var i = 0; i < 3; i++) {
    var x = questoes[questaoAtual].x[i];
    var y = questoes[questaoAtual].y[i];
    var w = questoes[questaoAtual].w[i];
    var h = questoes[questaoAtual].h[i];
    
    fill(247, 198, 228);
    if (mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
      fill(235, 162, 219);
    }
    rect(x, y, w, h, 30);
  }

  // Texto das alternativas
  fill(0);
  textAlign(CENTER);
  for (var i = 0; i < 3; i++) {
    text(textos[questaoAtual][i], 200, 280 + i * 50);
  }
}
